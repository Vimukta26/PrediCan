package com.example.skin_cancer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
